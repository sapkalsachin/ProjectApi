<?php
$date = date('Y-m-d H:i:s');
// echo "Today is " . date("Y/m/d") . "<br>";
// echo "Today is " . date("Y.m.d") . "<br>";
// echo "Today is " . date("Y-m-d") . "<br>";
echo " " . $timeDate = date("l/Y/M/d h:i:sa"). "<br>";
//echo "string to date is".date("l/y/m/d h:i:sa","Saturday/18/04/14 09:04:58pm");
//echo $date;
?>